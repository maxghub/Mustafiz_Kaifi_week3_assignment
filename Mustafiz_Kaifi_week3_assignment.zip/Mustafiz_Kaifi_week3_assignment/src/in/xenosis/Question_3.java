package in.xenosis;


//Develop a simple program to demonstrate the
//        concept of abstract classes and interfaces.


// Abstract class Animal
abstract class Animal {
    String name;

    Animal(String name) {
        this.name = name;
    }

    // Abstract method
    abstract void sound();

    // Concrete method
    void eat() {
        System.out.println(name + " is eating.");
    }
}

// Interface Pet
interface Pet {
    void play();
    void cuddle();
}

// Concrete class Dog extending Animal and implementing Pet
class Dog extends Animal implements Pet {

    Dog(String name) {
        super(name);
    }

    // Implementing abstract method from Animal
    @Override
    void sound() {
        System.out.println(name + " barks.");
    }

    // Implementing methods from Pet interface
    @Override
    public void play() {
        System.out.println(name + " is playing.");
    }

    @Override
    public void cuddle() {
        System.out.println(name + " is cuddling.");
    }
}

// Main class to demonstrate the concepts
public class Question_3 {
    public static void main(String[] args) {
        // Creating an instance of Dog
        Dog dog = new Dog("Buddy");


        dog.sound();    // Output: Buddy barks.
        dog.eat();      // Output: Buddy is eating.
        dog.play();     // Output: Buddy is playing.
        dog.cuddle();   // Output: Buddy is cuddling.
    }
}

