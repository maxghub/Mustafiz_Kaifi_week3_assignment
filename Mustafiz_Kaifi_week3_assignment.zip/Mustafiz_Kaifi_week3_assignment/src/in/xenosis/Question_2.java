package in.xenosis;



//Implement a Shape class with derived classes
//        Circle, Rectangle, and Triangle, each having a
//        method to calculate the area.

// Base class
abstract class Shape {
    abstract double calculateArea();
}

// Derived class Circle
class Circle extends Shape {
    double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double calculateArea() {
        return Math.PI * radius * radius;
    }
}

// Derived class Rectangle
class Rectangle extends Shape {
    double width, height;

    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    double calculateArea() {
        return width * height;
    }
}

// Derived class Triangle
class Triangle extends Shape {
    double base, height;

    Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    @Override
    double calculateArea() {
        return 0.5 * base * height;
    }
}

// Main class to test the shapes
public class Question_2 {
    public static void main(String[] args) {
        // Create instances of Circle, Rectangle, and Triangle
        Shape circle = new Circle(5);
        Shape rectangle = new Rectangle(4, 6);
        Shape triangle = new Triangle(3, 7);

        
        System.out.println("Area of Circle: " + circle.calculateArea()); // Output: Area of Circle: 78.53981633974483
        System.out.println("Area of Rectangle: " + rectangle.calculateArea()); // Output: Area of Rectangle: 24.0
        System.out.println("Area of Triangle: " + triangle.calculateArea()); // Output: Area of Triangle: 10.5
    }
}


