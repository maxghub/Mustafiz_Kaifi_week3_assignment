package in.xenosis;


//Create a base class Vehicle and derived classes
//        Car and Bike. Implement method overriding and
//        demonstrate polymorphism.


class  Vehicle{
     void start(){
         System.out.println("Vehicle base class speed ");
     }
}
class Car extends  Vehicle{
    void start(){
        System.out.println("Car derived class speed");
    }
}
class Bike extends Vehicle{
    void start(){
        System.out.println("Bike derived class speed");
    }
}

public class Question_1 {
    public static void main(String[] args) {
        Vehicle v=new Vehicle();
        v.start();     //Vehicle base class speed

        Car c=new Car();
        c.start();     //Car derived class speed

        Vehicle c1=new Car();
        c1.start();   //Car derived class speed

        Bike b=new Bike();
        b.start();    //Bike derived class speed

        Vehicle b1=new Bike();
        b1.start();   //Bike derived class speed
    }
}
